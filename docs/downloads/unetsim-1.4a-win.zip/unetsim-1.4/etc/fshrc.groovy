def load(url) {
  try {
    run(url)
  } catch (FileNotFoundException ex) {
    log.log(INFO, "$url: file not found, skipping it!")
  } catch (ClassNotFoundException ex) {
    log.log(INFO, "$url: class not found, skipping it!")
  } catch (ex) {
    log.log(WARNING, "$url: loading failed", ex)
  }
}

scripts = 'scripts'

load('cls://org.arl.unet.shell.fshrc_core')
load('cls://org.arl.unet.shell.fshrc_state')
load('cls://org.arl.unet.shell.fshrc_nodeinfo')
load('cls://org.arl.unet.shell.fshrc_phy')
load('cls://org.arl.unet.shell.fshrc_bb')

load('cls://org.arl.unet.shell.fshrc_arp')
load('cls://org.arl.unet.shell.fshrc_ranging')
load('cls://org.arl.unet.shell.fshrc_mac')
load('cls://org.arl.unet.shell.fshrc_aloha')
load('cls://org.arl.unet.shell.fshrc_maca')
load('cls://org.arl.unet.shell.fshrc_link')
load('cls://org.arl.unet.shell.fshrc_transport')
load('cls://org.arl.unet.shell.fshrc_net')
load('cls://org.arl.unet.shell.fshrc_remote')
load('cls://org.arl.unet.shell.fshrc_scheduler')
load('cls://org.arl.unet.shell.fshrc_bbmon')

def fshrcScript = new File('etc/fshrc_local.groovy')
if (fshrcScript.exists()) {
  run fshrcScript
  return
}

fshrcScript = new File('scripts/fshrc.groovy')
if (fshrcScript.exists()) {
  run fshrcScript
  return
}
