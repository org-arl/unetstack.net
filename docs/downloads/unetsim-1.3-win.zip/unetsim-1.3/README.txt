Unet Simulator
==============

Getting started
---------------

To test the simulator on your computer, run the UnetIDE application,
open samples/super-tdma/e3-network.groovy and run it. If you prefer
a command line, open a terminal window in the unet folder (where
this README.txt is) and try:

  bin/unet samples/super-tdma/e3-network.groovy

If everything goes well, you should see an output similar to:

  Equilateral triangle network
  ----------------------------

  Internode distance:     650 m
  Slot length:            422 ms
  Simulation time:        900 s
  TX:                     3198
  RX:                     3195
  Offered load:           1.226
  Throughput:             1.225

  1 simulation completed in 2.803 seconds

If not, visit the support forum at http://www.unetstack.net/support/
to seek help on resolving the problem.

To get going with your own simulations, refer to the quick start guide at:
http://www.unetstack.net/doc/html/quickstart.html


Requirements
------------

Mac OS X / Linux / Windows


Bundled Dependencies
--------------------

The Unet simulator depends on the several open-source software libraries that
are bundled together in this package in binary form:

Groovy - Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.html)
Apache Commons Lang - Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.html)
fjåge - BSD License (https://raw.github.com/org-arl/fjage/master/LICENSE.txt)
jline - BSD License (https://raw.github.com/jline/jline2/master/LICENSE.txt)
jfreechart - LGPL License (http://www.gnu.org/licenses/lgpl-3.0.txt)
jcommon - LGPL License (http://www.gnu.org/licenses/lgpl-3.0.txt)
jtransforms - Mozilla Public License (http://www.mozilla.org/MPL/2.0/)
GSON - Apache License v2 (http://www.apache.org/licenses/LICENSE-2.0.html)

Oracle's JDK 1.8 (http://www.oracle.com/technetwork/java/javase/downloads/index.html)
is bundled as part of the UnetIDE application.
